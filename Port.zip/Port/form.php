<html>
    <body>
        <style>
        </style>
    </body>
</html>

<?php
$res = $_REQUEST['res'];

if ($res == "Resume")
{
    echo"<p>Kamali Lama
    1123 2nd Avenue S. APT 12
    Moorhead MN, 56560
    Cell: 218-979-4429
    lamakam@mnstate.edu
    
    Summary                           
    
    I am a junior at Minnesota State University Moorhead and I plan to graduate on Spring 2019. My major is Computer Information Technology. This resume is designed for my internship opportunity as Application Developer. 
    
    
    Write about your self
    
    I am a curious person who believes in hard work, creativity and discovery. I would like to call myself an enthusiast person always seeking for an opportunity to know myself better and make my self a better human. I am a very simple person and passionate at the same time about certain things that engage me into thinking. One thing that tells the best about myself is I like fixing things or you can say solving problem.
    
    Education												
    
    Minnesota State University Moorhead, (MSUM) Moorhead MN………………………	May 2019
    Bachelors of Science in Computer Information Technology
        
    Core Competencies 										
    
     
    •	Analytical Thinking 
    •	Problem Solving 
    •	Adaptability
    •	Integrity
    •	Reliability
    •	Initiative
    •	Client-Focus
    •	Excellent Communication Skills
    •	Team Work
    •	Self Training/Coaching
     
    
    Skills													
        
    •	Python
    •	PHP
    •	JavaScript
    •	C++
    •	SQL
    
    Brief description of what I learned
    
    Python was the first Object Oriented Programming language I learned. All the languages I’ve learnt has taught me how to think out of the box, to solve complex problem, to write an algorithm, to work as a team, to work in a time limit environment. The most important thing I’ve learned is not give up.
    
    Job Experience 											
    
    Minnesota State University, Information Technology……………………..	08/205 – 05/2019
    
    Helpdesk Support Technician 
    
    •	Received and responded to phone calls and email requests for technical assistance in a call center environment  
    •	Monitored ticket system and provided second tier support for other peripheral equipment such as printers, scanners, and copiers  
    •	Utilized different applications like Active Directory, Application Database, Bomgar, SharePoint, Cisco VPN while at work  
    •	Assisted MSUM faculty/staff and students with technology issues and for further assistance guided them to appropriate IT Technicians  
    •	Installed software on staffs computer as needed and provided assistance with hardware issues
    •	Walked customers through problem-solving process  
    •	Followed up with the customers in a timely manner to ensure issue has been resolved 
    •	Conducted Weekly Meeting for Team members and Steering Team to update the work status
    •	Collaborated with project team in defining possible solutions to business needs
    
    
<p>";    
}

?>